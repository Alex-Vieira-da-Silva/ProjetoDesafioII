﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk.Query;
using System.Linq.Expressions;
using System.IdentityModel.Metadata;


namespace ProjetoDesafioII
{
    public class WorkflowValidarQuantidadeIncriçõesAluno : CodeActivity
    {
        #region Parametros
        //Recebe o usuário do Context
        [Input("Usuario")]
        [ReferenceTarget("systemuser")]
        public InArgument<EntityReference> usuarioEntrada { get; set; }

        //Rcebe o context
        [Input("AlunoXCursoDisponivel")]
        [ReferenceTarget("dio_alunoxcursodisponivel")]
        public InArgument<EntityReference> RegistroContexto { get; set; }

        [Output("Saida")]
        public OutArgument<string> saida { get; set; }
        #endregion
        protected override void Execute(CodeActivityContext ExecuteContext)
        {
            IWorkflowContext context = ExecuteContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = ExecuteContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            ITracingService trace = ExecuteContext.GetExtension<ITracingService>();

            trace.Trace("dio_alunoxcursodisponivel: " + context.PrimaryEntityId);

            Guid guidAlunoXCurso = context.PrimaryEntityId;

            trace.Trace("guidAlunoXCurso: " + guidAlunoXCurso);

            String fetchAlunoXCursos = "<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>";
            fetchAlunoXCursos += "<entity name='dio_alunoxcursodisponivel'>";
            fetchAlunoXCursos += "<attribute name='dio_alunoxcursodisponivelid' />";
            fetchAlunoXCursos += "<attribute name='dio_name' />";
            fetchAlunoXCursos += "<attribute name='dio_emcurso' />";
            fetchAlunoXCursos += "<attribute name='createdon' />";
            fetchAlunoXCursos += "<attribute name='dio_aluno' />";
            fetchAlunoXCursos += "<order descending='false' attribute='dio_name' />";
            fetchAlunoXCursos += "<filter type='and'>";
            fetchAlunoXCursos += "<condition attribute='dio_alunoxcursodisponivelid' value='" + guidAlunoXCurso + "' uitype='dio_alunoxcursodisponivel' />";
            fetchAlunoXCursos += "</filter>";
            fetchAlunoXCursos += "</entity>";
            fetchAlunoXCursos += "</fetch>";
            trace.Trace("fetchAlunoXCursos: " + fetchAlunoXCursos);

            var entityAlunoXCurso = service.RetrieveMultiple(new FetchExpression(fetchAlunoXCursos));
            trace.Trace("entityAlunoXCurso: " + entityAlunoXCurso.Entities.Count);

            Guid guidAluno = Guid.Empty;
            foreach(var item in entityAlunoXCurso.Entities)
            {
                string nomeCurso = item.Attributes["dio_name"].ToString();
                trace.Trace("nomeCurso: " +  nomeCurso);

                var entityAluno = ((EntityReference)item.Attributes["dio_aluno"]).Id;
                guidAluno = ((EntityReference)item.Attributes["dio_aluno"]).Id;
                trace.Trace("entityAluno: " + entityAluno);
            }

            String fetchAlunoXCursosQtde = "<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>";
            fetchAlunoXCursosQtde += "<entity name='dio_alunoxcursodisponivel'>";
            fetchAlunoXCursosQtde += "<attribute name='dio_alunoxcursodisponivelid' />";
            fetchAlunoXCursosQtde += "<attribute name='dio_name' />";
            fetchAlunoXCursosQtde += "<attribute name='dio_emcurso' />";
            fetchAlunoXCursosQtde += "<attribute name='createdon' />";
            fetchAlunoXCursosQtde += "<attribute name='dio_aluno' />";
            fetchAlunoXCursosQtde += "<order descending='false' attribute='dio_name' />";
            fetchAlunoXCursosQtde += "<filter type='and'>";
            fetchAlunoXCursosQtde += "<condition attribute='dio_alunoxcursodisponivelid' value='" + guidAluno + "' uitype='dio_alunoxcursodisponivel' />";
            fetchAlunoXCursosQtde += "</filter>";
            fetchAlunoXCursosQtde += "</entity>";
            fetchAlunoXCursosQtde += "</fetch>";
            trace.Trace("fetchAlunoXCursosQtde: " + fetchAlunoXCursosQtde);

            var entityfetchAlunoXCursosQtde = service.RetrieveMultiple(new FetchExpression(fetchAlunoXCursosQtde));
            trace.Trace("entityfetchAlunoXCursosQtde: " + entityfetchAlunoXCursosQtde.Entities.Count);
            if(entityfetchAlunoXCursosQtde.Entities.Count > 2)
            {
                saida.Set(ExecuteContext, "Aluno excedeu o limite de cursos ativos!");
                trace.Trace("Aluno excedeu o limite de cursos ativos!");
                throw new InvalidPluginExecutionException("Aluno excedeu o limite de cursos ativos!");
            }

        }
    }
}
